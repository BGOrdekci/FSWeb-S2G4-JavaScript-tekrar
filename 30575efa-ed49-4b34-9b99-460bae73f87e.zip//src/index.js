var derp = ['string,','string2'];

console.log( derp.toString(' , ') )